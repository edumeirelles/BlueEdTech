﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Teste_03_04_05_06_07.Models
{
    public class clsTeste
    {
        public int codigo { get; set; }
        public string descricao { get; set; }
    }
}
